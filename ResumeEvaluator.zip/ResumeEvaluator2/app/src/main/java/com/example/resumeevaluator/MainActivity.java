package com.example.resumeevaluator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText resumeInput;
    private TextView resultText;
    private Button evaluateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resumeInput = findViewById(R.id.resumeInput);
        resultText = findViewById(R.id.resultText);
        evaluateButton = findViewById(R.id.evaluateButton);

        evaluateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resumeText = resumeInput.getText().toString();
                String evaluationResult = evaluateResume(resumeText);
                resultText.setText(evaluationResult);
            }
        });
    }

    private String evaluateResume(String resume) {
        if (resume.isEmpty()) {
            return "Please enter a resume.";
        }

        // Define keyword categories and weights
        Map<String, Integer> keywords = new HashMap<>();
        keywords.put("Java", 10);
        keywords.put("Android", 10);
        keywords.put("Kotlin", 8);
        keywords.put("SQL", 7);
        keywords.put("Machine Learning", 6);
        keywords.put("AI", 6);
        keywords.put("REST API", 5);
        keywords.put("Agile", 4);

        int score = 0;
        for (Map.Entry<String, Integer> entry : keywords.entrySet()) {
            if (resume.toLowerCase().contains(entry.getKey().toLowerCase())) {
                score += entry.getValue();
            }
        }

        if (score > 30) {
            return "Strong Resume! Score: " + score;
        } else if (score > 15) {
            return "Decent Resume. Score: " + score;
        } else {
            return "Needs Improvement. Score: " + score;
 }
}
}